extends Node3D

# Online prototype: up to 20 connected players. One player hosts the match.
const MAX_PLAYERS := 20
const PORT := 7777
const ARENA_SIZE := 90.0
# Replace with your deployed HTTPS OTP backend URL before release.
const AUTH_API_BASE := "https://YOUR_AUTH_SERVER_DOMAIN"

var actors: Dictionary = {}
var local_player: CharacterBody3D
var elapsed := 0.0
var zone_radius := 43.0
var game_started := false
var hud: Label
var status: Label
var address_input: LineEdit
var menu_panel: Panel
var fire_button: Button
var jump_requested := false
var touch_move := Vector2.ZERO
var move_finger := -1
var look_finger := -1
var auth_request: HTTPRequest
var auth_phone := ""
var auth_token := ""
var auth_user_id := ""
var auth_panel: Panel
var auth_phone_input: LineEdit
var auth_otp_input: LineEdit
var auth_message: Label

func _ready():
    randomize()
    _build_world()
    _build_auth_screen()
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected_to_server)
    multiplayer.connection_failed.connect(_on_connection_failed)
    multiplayer.server_disconnected.connect(_on_server_disconnected)


func _build_auth_screen():
    var layer = CanvasLayer.new()
    add_child(layer)
    auth_request = HTTPRequest.new()
    auth_request.timeout = 20.0
    add_child(auth_request)
    auth_request.request_completed.connect(_on_auth_response)

    auth_panel = Panel.new()
    auth_panel.position = Vector2(390, 145)
    auth_panel.size = Vector2(500, 430)
    layer.add_child(auth_panel)

    var title = Label.new()
    title.text = "BATTLE ROYALE BABRA"
    title.position = Vector2(65, 22)
    title.add_theme_font_size_override("font_size", 30)
    auth_panel.add_child(title)

    var subtitle = Label.new()
    subtitle.text = "MOBILE NUMBER LOGIN"
    subtitle.position = Vector2(125, 70)
    subtitle.add_theme_font_size_override("font_size", 18)
    auth_panel.add_child(subtitle)

    var phone_label = Label.new()
    phone_label.text = "Mobile number (+91)"
    phone_label.position = Vector2(55, 125)
    auth_panel.add_child(phone_label)

    auth_phone_input = LineEdit.new()
    auth_phone_input.placeholder_text = "9876543210"
    auth_phone_input.position = Vector2(55, 155)
    auth_phone_input.size = Vector2(390, 45)
    auth_phone_input.max_length = 10
    auth_phone_input.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
    auth_panel.add_child(auth_phone_input)

    var send_button = Button.new()
    send_button.text = "SEND OTP"
    send_button.position = Vector2(55, 215)
    send_button.size = Vector2(180, 50)
    send_button.pressed.connect(_request_otp)
    auth_panel.add_child(send_button)

    var otp_label = Label.new()
    otp_label.text = "Enter 6-digit OTP"
    otp_label.position = Vector2(55, 280)
    auth_panel.add_child(otp_label)

    auth_otp_input = LineEdit.new()
    auth_otp_input.placeholder_text = "6-digit OTP"
    auth_otp_input.position = Vector2(55, 310)
    auth_otp_input.size = Vector2(220, 45)
    auth_otp_input.max_length = 6
    auth_otp_input.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
    auth_panel.add_child(auth_otp_input)

    var verify_button = Button.new()
    verify_button.text = "VERIFY & LOGIN"
    verify_button.position = Vector2(290, 310)
    verify_button.size = Vector2(155, 45)
    verify_button.pressed.connect(_verify_otp)
    auth_panel.add_child(verify_button)

    auth_message = Label.new()
    auth_message.text = "Enter your number to receive an OTP."
    auth_message.position = Vector2(55, 375)
    auth_message.size = Vector2(390, 45)
    auth_message.autowrap_mode = TextServer.AUTOWRAP_WORD
    auth_panel.add_child(auth_message)

func _request_otp():
    var digits = auth_phone_input.text.strip_edges()
    if not digits.is_valid_int() or digits.length() != 10:
        auth_message.text = "Please enter a valid 10-digit Indian mobile number."
        return
    if AUTH_API_BASE.contains("YOUR_AUTH_SERVER_DOMAIN"):
        auth_message.text = "OTP service setup is required. No SMS has been sent yet."
        return
    auth_phone = "+91" + digits
    var body = JSON.stringify({"phone": auth_phone})
    var headers = PackedStringArray(["Content-Type: application/json"])
    var err = auth_request.request(AUTH_API_BASE + "/auth/send-otp", headers, HTTPClient.METHOD_POST, body)
    auth_message.text = "Requesting OTP..." if err == OK else "Could not contact login server."

func _verify_otp():
    var code = auth_otp_input.text.strip_edges()
    if auth_phone.is_empty():
        auth_message.text = "First enter your mobile number and tap SEND OTP."
        return
    if not code.is_valid_int() or code.length() != 6:
        auth_message.text = "Please enter the 6-digit OTP."
        return
    if AUTH_API_BASE.contains("YOUR_AUTH_SERVER_DOMAIN"):
        auth_message.text = "OTP server setup is required. Verification is not active yet."
        return
    var body = JSON.stringify({"phone": auth_phone, "otp": code})
    var headers = PackedStringArray(["Content-Type: application/json"])
    var err = auth_request.request(AUTH_API_BASE + "/auth/verify-otp", headers, HTTPClient.METHOD_POST, body)
    auth_message.text = "Verifying OTP..." if err == OK else "Could not contact login server."

func _on_auth_response(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray):
    if result != HTTPRequest.RESULT_SUCCESS:
        auth_message.text = "Network error. Check your internet connection."
        return
    var parsed = JSON.parse_string(body.get_string_from_utf8())
    if response_code < 200 or response_code >= 300 or typeof(parsed) != TYPE_DICTIONARY:
        auth_message.text = "Login failed. Check details and try again."
        return
    if parsed.has("error"):
        auth_message.text = str(parsed["error"])
        return
    if parsed.has("accessToken") and parsed.has("userId"):
        auth_token = str(parsed["accessToken"])
        auth_user_id = str(parsed["userId"])
        auth_message.text = "Login successful!"
        auth_panel.visible = false
        _build_menu()
    else:
        auth_message.text = "Unexpected response from login server."

func _build_menu():
    var layer = CanvasLayer.new()
    add_child(layer)
    menu_panel = Panel.new()
    menu_panel.position = Vector2(390, 190)
    menu_panel.size = Vector2(500, 340)
    layer.add_child(menu_panel)

    var title = Label.new()
    title.text = "BATTLE ROYALE BABRA"
    title.position = Vector2(80, 25)
    title.add_theme_font_size_override("font_size", 30)
    menu_panel.add_child(title)

    var subtitle = Label.new()
    subtitle.text = "ONLINE MULTIPLAYER • BABRA, PALI"
    subtitle.position = Vector2(95, 75)
    subtitle.add_theme_font_size_override("font_size", 17)
    menu_panel.add_child(subtitle)

    address_input = LineEdit.new()
    address_input.placeholder_text = "Host IP address (e.g. 123.45.67.89)"
    address_input.text = "127.0.0.1"
    address_input.position = Vector2(60, 125)
    address_input.size = Vector2(380, 42)
    menu_panel.add_child(address_input)

    var host_button = Button.new()
    host_button.text = "HOST MATCH"
    host_button.position = Vector2(60, 190)
    host_button.size = Vector2(175, 55)
    host_button.pressed.connect(_host_match)
    menu_panel.add_child(host_button)

    var join_button = Button.new()
    join_button.text = "JOIN MATCH"
    join_button.position = Vector2(265, 190)
    join_button.size = Vector2(175, 55)
    join_button.pressed.connect(_join_match)
    menu_panel.add_child(join_button)

    status = Label.new()
    status.text = "Host: start a room. Friends: enter host IP and join."
    status.position = Vector2(35, 270)
    status.size = Vector2(430, 50)
    status.add_theme_font_size_override("font_size", 15)
    menu_panel.add_child(status)

func _host_match():
    var peer = ENetMultiplayerPeer.new()
    var result = peer.create_server(PORT, MAX_PLAYERS - 1)
    if result != OK:
        status.text = "Could not host. Error: %s" % result
        return
    multiplayer.multiplayer_peer = peer
    status.text = "Room hosted on port %d. Share your public IP." % PORT
    _start_match()
    spawn_player.rpc(multiplayer.get_unique_id())

func _join_match():
    var peer = ENetMultiplayerPeer.new()
    var result = peer.create_client(address_input.text.strip_edges(), PORT)
    if result != OK:
        status.text = "Could not connect. Check IP and internet."
        return
    multiplayer.multiplayer_peer = peer
    status.text = "Connecting to host..."

func _on_connected_to_server():
    status.text = "Connected! Waiting for Babra match..."
    menu_panel.visible = false

func _on_connection_failed():
    status.text = "Connection failed. Check host IP, port 7777 and firewall."

func _on_server_disconnected():
    status.text = "Host disconnected. Return to menu and reconnect."
    menu_panel.visible = true
    game_started = false

func _on_peer_connected(id: int):
    if multiplayer.is_server():
        # Spawn the joining player for everyone, then send existing players to newcomer.
        spawn_player.rpc(id)
        for existing_id in actors.keys():
            if int(existing_id) != id:
                spawn_player.rpc_id(id, int(existing_id))

func _on_peer_disconnected(id: int):
    if actors.has(id):
        actors[id].queue_free()
        actors.erase(id)

func _start_match():
    game_started = true
    menu_panel.visible = false
    _build_hud()

@rpc("authority", "call_local", "reliable")
func spawn_player(peer_id: int):
    if actors.has(peer_id):
        return
    var palette = [Color(0.10, 0.52, 0.95), Color(0.95, 0.45, 0.10), Color(0.2, 0.8, 0.35),
        Color(0.8, 0.25, 0.7), Color(0.9, 0.8, 0.15)]
    var actor = _make_actor(palette[abs(peer_id) % palette.size()])
    actor.name = "Player_%d" % peer_id
    actor.position = Vector3(randf_range(-12, 12), 0, randf_range(-12, 12))
    add_child(actor)
    actors[peer_id] = actor
    if peer_id == multiplayer.get_unique_id():
        local_player = actor
        _attach_camera(actor)
    _refresh_hud()

func _make_actor(color: Color) -> CharacterBody3D:
    var body = CharacterBody3D.new()
    var visual = MeshInstance3D.new()
    var capsule = CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 1.8
    visual.mesh = capsule
    var mat = StandardMaterial3D.new()
    mat.albedo_color = color
    visual.material_override = mat
    visual.position.y = 0.9
    body.add_child(visual)
    var collision = CollisionShape3D.new()
    var shape = CapsuleShape3D.new()
    shape.radius = 0.48
    shape.height = 1.8
    collision.shape = shape
    collision.position.y = 0.9
    body.add_child(collision)
    body.set_meta("hp", 100.0)
    return body

func _attach_camera(actor: CharacterBody3D):
    var pivot = Node3D.new()
    pivot.position.y = 1.45
    actor.add_child(pivot)
    var camera = Camera3D.new()
    camera.position = Vector3(0, 3.2, 7.5)
    camera.rotation_degrees.x = -18
    camera.current = true
    pivot.add_child(camera)
    actor.set_meta("pivot", pivot)
    actor.set_meta("camera", camera)

func _build_hud():
    if hud:
        return
    var layer = CanvasLayer.new()
    add_child(layer)
    hud = Label.new()
    hud.position = Vector2(20, 16)
    hud.add_theme_font_size_override("font_size", 23)
    hud.add_theme_color_override("font_color", Color.WHITE)
    layer.add_child(hud)
    var help = Label.new()
    help.text = "WASD / left touch: move  •  Mouse / right touch: look  •  FIRE  •  JUMP"
    help.position = Vector2(20, 680)
    help.add_theme_font_size_override("font_size", 15)
    layer.add_child(help)
    fire_button = Button.new()
    fire_button.text = "FIRE"
    fire_button.position = Vector2(1100, 565)
    fire_button.size = Vector2(130, 90)
    fire_button.pressed.connect(_shoot)
    layer.add_child(fire_button)
    var jump_button = Button.new()
    jump_button.text = "JUMP"
    jump_button.position = Vector2(970, 590)
    jump_button.size = Vector2(110, 65)
    jump_button.pressed.connect(func(): jump_requested = true)
    layer.add_child(jump_button)

func _input(event):
    if not game_started or not local_player:
        return
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < get_viewport().get_visible_rect().size.x * 0.48 and move_finger == -1:
                move_finger = event.index
                _update_touch_move(event.position)
            elif event.position.x >= get_viewport().get_visible_rect().size.x * 0.48 and look_finger == -1:
                look_finger = event.index
        else:
            if event.index == move_finger:
                move_finger = -1
                touch_move = Vector2.ZERO
            if event.index == look_finger:
                look_finger = -1
    elif event is InputEventScreenDrag:
        if event.index == move_finger:
            _update_touch_move(event.position)
        elif event.index == look_finger:
            _rotate_local_camera(event.relative.x, event.relative.y)
    elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        _rotate_local_camera(event.relative.x, event.relative.y)
    elif event is InputEventKey and event.keycode == KEY_ESCAPE and event.pressed:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _update_touch_move(position: Vector2):
    var screen = get_viewport().get_visible_rect().size
    var center = Vector2(screen.x * 0.17, screen.y * 0.78)
    touch_move = (position - center).limit_length(95.0) / 95.0

func _rotate_local_camera(dx: float, dy: float):
    local_player.rotate_y(-dx * 0.003)
    var pivot: Node3D = local_player.get_meta("pivot")
    pivot.rotate_x(-dy * 0.002)
    pivot.rotation.x = clamp(pivot.rotation.x, -0.65, 0.35)

func _physics_process(delta):
    if not game_started or not local_player:
        return
    elapsed += delta
    zone_radius = max(12.0, 43.0 - elapsed * 0.12)
    _move_local_player(delta)
    # Send this player's transform to the server; the server relays it to all peers.
    var my_id = multiplayer.get_unique_id()
    if multiplayer.is_server():
        update_remote.rpc(my_id, local_player.global_position, local_player.rotation.y)
    else:
        submit_state.rpc_id(1, local_player.global_position, local_player.rotation.y)
    if local_player.global_position.length() > zone_radius:
        local_player.set_meta("hp", max(0.0, float(local_player.get_meta("hp")) - 7.0 * delta))
    _refresh_hud()

func _move_local_player(delta):
    var input_dir = Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    if touch_move.length() > 0.08:
        input_dir = touch_move
    var direction = (local_player.transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
    local_player.velocity.x = direction.x * 7.0
    local_player.velocity.z = direction.z * 7.0
    if not local_player.is_on_floor():
        local_player.velocity.y -= 22.0 * delta
    else:
        local_player.velocity.y = -0.5
        if jump_requested:
            local_player.velocity.y = 8.0
    jump_requested = false
    local_player.move_and_slide()

@rpc("any_peer", "call_remote", "unreliable")
func submit_state(position: Vector3, yaw: float):
    if not multiplayer.is_server():
        return
    var sender = multiplayer.get_remote_sender_id()
    if not actors.has(sender):
        return
    # Basic arena bounds check to reject impossible coordinates.
    if abs(position.x) > ARENA_SIZE or abs(position.z) > ARENA_SIZE:
        return
    update_remote.rpc(sender, position, yaw)

@rpc("authority", "call_remote", "unreliable")
func update_remote(peer_id: int, position: Vector3, yaw: float):
    if not actors.has(peer_id):
        return
    if peer_id == multiplayer.get_unique_id():
        return
    var actor: CharacterBody3D = actors[peer_id]
    actor.global_position = actor.global_position.lerp(position, 0.65)
    actor.rotation.y = yaw

func _shoot():
    if not game_started or not local_player:
        return
    var camera: Camera3D = local_player.get_meta("camera")
    var origin = camera.global_position
    var direction = -camera.global_transform.basis.z
    if multiplayer.is_server():
        _server_shot(multiplayer.get_unique_id(), origin, direction)
    else:
        request_shot.rpc_id(1, origin, direction)

@rpc("any_peer", "call_remote", "reliable")
func request_shot(origin: Vector3, direction: Vector3):
    if multiplayer.is_server():
        _server_shot(multiplayer.get_remote_sender_id(), origin, direction)

func _server_shot(shooter_id: int, origin: Vector3, direction: Vector3):
    if not actors.has(shooter_id):
        return
    var shooter: CharacterBody3D = actors[shooter_id]
    # Keep shot origin close to the shooter's actual position.
    if origin.distance_to(shooter.global_position + Vector3.UP * 1.5) > 12.0:
        return
    var best_id := -1
    var best_distance := 65.0
    var ray = direction.normalized()
    for target_id in actors.keys():
        if int(target_id) == shooter_id:
            continue
        var target: CharacterBody3D = actors[target_id]
        var to_target = target.global_position + Vector3.UP - origin
        var along = to_target.dot(ray)
        if along < 0 or along > best_distance:
            continue
        var closest = origin + ray * along
        if closest.distance_to(target.global_position + Vector3.UP) < 1.2:
            best_distance = along
            best_id = int(target_id)
    if best_id != -1:
        apply_damage.rpc(best_id, 25.0)

@rpc("authority", "call_local", "reliable")
func apply_damage(peer_id: int, damage: float):
    if actors.has(peer_id):
        var actor: CharacterBody3D = actors[peer_id]
        actor.set_meta("hp", max(0.0, float(actor.get_meta("hp")) - damage))
        if float(actor.get_meta("hp")) <= 0:
            actor.visible = false

func _refresh_hud():
    if not hud:
        return
    var alive := 0
    for id in actors.keys():
        if float(actors[id].get_meta("hp")) > 0:
            alive += 1
    var hp = int(local_player.get_meta("hp")) if local_player else 0
    hud.text = "BATTLE ROYALE BABRA  |  PLAYERS: %d/%d  |  HP: %d  |  SAFE ZONE: %dm" % [alive, MAX_PLAYERS, hp, int(zone_radius)]

func _build_world():
    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -25, 0)
    sun.light_energy = 1.2
    add_child(sun)
    var world = WorldEnvironment.new()
    var env = Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.55, 0.62, 0.7)
    env.ambient_light_energy = 0.7
    world.environment = env
    add_child(world)

    var ground = StaticBody3D.new()
    var mesh = MeshInstance3D.new()
    var plane = PlaneMesh.new()
    plane.size = Vector2(ARENA_SIZE * 2, ARENA_SIZE * 2)
    mesh.mesh = plane
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.23, 0.39, 0.22)
    mesh.material_override = mat
    ground.add_child(mesh)
    var collision = CollisionShape3D.new()
    var shape = BoxShape3D.new()
    shape.size = Vector3(ARENA_SIZE * 2, 1, ARENA_SIZE * 2)
    collision.shape = shape
    collision.position.y = -0.5
    ground.add_child(collision)
    add_child(ground)
    _build_babra_village()

    for i in range(18):
        var tree = MeshInstance3D.new()
        var trunk = CylinderMesh.new()
        trunk.top_radius = 0.25
        trunk.bottom_radius = 0.4
        trunk.height = 2.4
        tree.mesh = trunk
        var side = -1.0 if randf() < 0.5 else 1.0
        tree.position = Vector3(side * randf_range(48, 82), 1.2, randf_range(-82, 82))
        var tm = StandardMaterial3D.new()
        tm.albedo_color = Color(0.3, 0.18, 0.08)
        tree.material_override = tm
        add_child(tree)
        var crown = MeshInstance3D.new()
        var sphere = SphereMesh.new()
        sphere.radius = 1.6
        sphere.height = 3.2
        crown.mesh = sphere
        crown.position = tree.position + Vector3(0, 2.2, 0)
        var cm = StandardMaterial3D.new()
        cm.albedo_color = Color(0.08, randf_range(0.25, 0.42), 0.1)
        crown.material_override = cm
        add_child(crown)


func _add_road(pos: Vector3, size: Vector3, color := Color(0.32, 0.30, 0.25)):
    var road = MeshInstance3D.new()
    var box = BoxMesh.new()
    box.size = size
    road.mesh = box
    road.position = pos
    var material = StandardMaterial3D.new()
    material.albedo_color = color
    road.material_override = material
    add_child(road)

func _add_house(pos: Vector3, scale := Vector3(1, 1, 1), wall_color := Color(0.72, 0.58, 0.39)):
    var house = Node3D.new()
    house.position = pos
    add_child(house)

    var walls = MeshInstance3D.new()
    var body_mesh = BoxMesh.new()
    body_mesh.size = Vector3(5.0, 3.0, 4.5) * scale
    walls.mesh = body_mesh
    walls.position.y = 1.5 * scale.y
    var wall_mat = StandardMaterial3D.new()
    wall_mat.albedo_color = wall_color
    walls.material_override = wall_mat
    house.add_child(walls)

    var roof = MeshInstance3D.new()
    var roof_mesh = BoxMesh.new()
    roof_mesh.size = Vector3(5.5, 0.45, 5.0) * scale
    roof.mesh = roof_mesh
    roof.position.y = 3.2 * scale.y
    var roof_mat = StandardMaterial3D.new()
    roof_mat.albedo_color = Color(0.42, 0.20, 0.12)
    roof.material_override = roof_mat
    house.add_child(roof)

    var door = MeshInstance3D.new()
    var door_mesh = BoxMesh.new()
    door_mesh.size = Vector3(0.9, 1.8, 0.12) * scale
    door.mesh = door_mesh
    door.position = Vector3(0, 0.9 * scale.y, 2.31 * scale.z)
    var door_mat = StandardMaterial3D.new()
    door_mat.albedo_color = Color(0.20, 0.12, 0.07)
    door.material_override = door_mat
    house.add_child(door)

func _add_landmark(label: String, pos: Vector3, size: Vector3, tint: Color):
    _add_house(pos, size, tint)
    var sign = Label3D.new()
    sign.text = label
    sign.position = pos + Vector3(0, 5.2, 0)
    sign.font_size = 48
    sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    sign.modulate = Color(1.0, 0.95, 0.72)
    add_child(sign)

func _build_babra_village():
    # Playable, compressed village layout inspired by Babra, Raipur, Pali.
    # Main village street and connecting lanes.
    _add_road(Vector3(0, 0.035, 0), Vector3(7.5, 0.07, 150))
    _add_road(Vector3(0, 0.04, 0), Vector3(150, 0.08, 7.0))
    _add_road(Vector3(-27, 0.045, 5), Vector3(5.0, 0.09, 100))
    _add_road(Vector3(27, 0.045, -8), Vector3(5.0, 0.09, 100))
    _add_road(Vector3(0, 0.05, -28), Vector3(65, 0.10, 4.5))
    _add_road(Vector3(0, 0.05, 29), Vector3(65, 0.10, 4.5))

    # Small village homes clustered along lanes.
    var house_colors = [
        Color(0.78, 0.65, 0.46), Color(0.68, 0.57, 0.43),
        Color(0.84, 0.76, 0.61), Color(0.61, 0.52, 0.40)
    ]
    for x in [-43, -36, -18, -11, 11, 18, 36, 43]:
        for z in [-42, -34, -18, -10, 10, 18, 34, 42]:
            if abs(x) < 14 and abs(z) < 14:
                continue
            var offset = Vector3(randf_range(-1.5, 1.5), 0, randf_range(-1.5, 1.5))
            _add_house(Vector3(x, 0, z) + offset, Vector3(randf_range(0.75, 1.0), 1, randf_range(0.75, 1.0)), house_colors[randi() % house_colors.size()])

    # Public/community landmarks represented as recognizable game locations.
    _add_landmark("GRAM PANCHAYAT", Vector3(-10, 0, -8), Vector3(1.25, 1.1, 1.25), Color(0.83, 0.75, 0.58))
    _add_landmark("GOVT SCHOOL", Vector3(18, 0, 15), Vector3(1.5, 1.0, 1.2), Color(0.77, 0.70, 0.54))
    _add_landmark("PHC BABRA", Vector3(-35, 0, 20), Vector3(1.25, 1.0, 1.0), Color(0.72, 0.78, 0.70))
    _add_landmark("BUS STAND", Vector3(34, 0, -22), Vector3(1.0, 0.8, 1.0), Color(0.78, 0.68, 0.48))
    _add_landmark("BAZAR", Vector3(9, 0, -17), Vector3(1.0, 0.9, 1.0), Color(0.78, 0.57, 0.36))

    # Village fields, dry scrub and a few wells around the settlement.
    for i in range(18):
        var field = MeshInstance3D.new()
        var field_mesh = BoxMesh.new()
        field_mesh.size = Vector3(randf_range(8, 17), 0.035, randf_range(8, 16))
        field.mesh = field_mesh
        field.position = Vector3(randf_range(-72, 72), 0.02, randf_range(-72, 72))
        var fm = StandardMaterial3D.new()
        fm.albedo_color = [Color(0.42, 0.39, 0.20), Color(0.35, 0.40, 0.18), Color(0.53, 0.44, 0.25)][randi() % 3]
        field.material_override = fm
        add_child(field)

    for pos in [Vector3(-62, 0, -52), Vector3(61, 0, 48), Vector3(-58, 0, 57)]:
        var well = MeshInstance3D.new()
        var cylinder = CylinderMesh.new()
        cylinder.top_radius = 1.5
        cylinder.bottom_radius = 1.7
        cylinder.height = 0.8
        well.mesh = cylinder
        well.position = pos + Vector3(0, 0.4, 0)
        var wm = StandardMaterial3D.new()
        wm.albedo_color = Color(0.45, 0.42, 0.34)
        well.material_override = wm
        add_child(well)

