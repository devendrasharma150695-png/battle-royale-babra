# BATTLE ROYALE BABRA ONLINE — Mobile OTP login prototype

## Added
- Indian mobile number (+91) login screen
- Send OTP and Verify & Login actions
- HTTPS API integration hooks
- Multiplayer menu opens only after backend confirms the OTP
- Existing ENet multiplayer prototype and Babra-inspired village map retained

## Real OTP setup required
Real SMS delivery is not active until you deploy an HTTPS authentication backend and connect an SMS OTP provider. This project does not generate fake OTPs and contains no SMS-provider secrets.

In `scripts/game.gd`, replace:
`AUTH_API_BASE = "https://YOUR_AUTH_SERVER_DOMAIN"`
with your deployed backend URL.

### Backend API contract

`POST /auth/send-otp`
Request:
`{"phone":"+919876543210"}`
Success:
`{"message":"OTP sent"}`

`POST /auth/verify-otp`
Request:
`{"phone":"+919876543210","otp":"123456"}`
Success:
`{"accessToken":"short-lived-session-token","userId":"stable-user-id","displayName":"Player"}`

The backend must generate OTPs securely, expire them quickly (about 5 minutes), rate-limit sends and attempts, store only a hash, use HTTPS, keep SMS API credentials server-side, and issue a short-lived session token. Never log OTPs or tokens.

## Multiplayer security note
This is still a peer-hosted ENet prototype. For a public production game, the dedicated game server must validate the login token and authoritatively manage movement, damage, match results and anti-cheat. The current client sends login requests but the prototype host does not yet validate the token.

## Build
Open `project.godot` in Godot 4.3+. Android export requires Godot Android export templates plus Android SDK/JDK. This ZIP is source code, not a compiled APK.
